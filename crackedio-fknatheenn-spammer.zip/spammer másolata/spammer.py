import requests
import multiprocessing
import random
import time
import string
from colorama import Fore, Style
from datetime import datetime
from json import loads, dumps
from time import sleep
from websocket import create_connection
from concurrent.futures import ThreadPoolExecutor

current_time = datetime.now().strftime("%H:%M:%S")

TOKENS_FILE = "tokens.txt"
PROXIES_FILE = "proxies.txt"
USER_IDS_FILE = "userids.txt"

CHANNEL_ID = "Put your CHANNEL ID to Spam :D"
MESSAGE_CONTENT = "<@userid> text to spam" # leave the <@userid> there!
NUM_PROCESSES = 100
MESSAGES_PER_PROCESS = 10000
import ctypes
ctypes.windll.kernel32.SetConsoleTitleW("DyingV1 made by cracked.io/fknAtheenN - Leave a rep if you like")
sent_message_count = multiprocessing.Value('i', 0)

def generate_random_string(length):
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for _ in range(length))

def send_message(tokens, proxy, user_ids):
    headers = {
        "content-type": "application/json",
        "accept": "*/*",
        "accept-encoding": "gzip, deflate, br",
        "accept-language": "hu",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.70 Chrome/108.0.5359.215 Electron/22.3.12 Safari/537.36",
    }

    if proxy:
        proxies = {"http": proxy, "https": proxy}
    else:
        proxies = None

    for _ in range(MESSAGES_PER_PROCESS):
        selected_user_ids = random.sample(user_ids, min(15, len(user_ids)))
        user_mentions = " ".join([f"<@{user_id}>" for user_id in selected_user_ids])
        message = MESSAGE_CONTENT.replace("<@userid>", user_mentions)
        generated_content = generate_random_string(6)
        message += f" | {generated_content}"
        url = f"https://discord.com/api/v10/channels/{CHANNEL_ID}/messages"
        data = {"content": message}

        token = random.choice(tokens) 
        token_str = token[0] if isinstance(token, list) else token

        headers["Authorization"] = token_str

        response = None
        try:
            response = requests.post(url, headers=headers, json=data, proxies=proxies)
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            print(
                f"{Style.BRIGHT} {Fore.RED} pajeet ~$ {Fore.YELLOW}Failed to send message: {e}{Fore.RESET}"
            )
            if response is not None:
                print(f"{Style.BRIGHT} {Fore.RED} pajeet ~$ {Fore.YELLOW}Failed to send message{Fore.RESET}")
            continue

        if response.status_code == 200:
            with sent_message_count.get_lock():
                sent_message_count.value += 1
            print(
                f"{Style.BRIGHT} {Fore.MAGENTA} pajeet ~$ {Fore.GREEN} Message sent to {Fore.LIGHTMAGENTA_EX}{CHANNEL_ID}{Fore.RESET}> {Fore.CYAN}{sent_message_count.value}{Fore.RESET}"
            )
        elif response.status_code == 429:
            print(
                f"{Style.BRIGHT} {Fore.RED} pajeet ~$ {Fore.YELLOW}Ratelimited waiting 5s{Fore.RESET}"
                
            )
            
        else:
            print(
                f"{Style.BRIGHT} {Fore.RED} pajeet ~$ {Fore.YELLOW}Failed to send message: {response.text}{Fore.RESET}"
            )

def on_message(ws, message):
    print(f"Received message: {message}")

def run_voice(token, guild_id, channel_id, mute, deaf):
    ws = create_connection("wss://gateway.discord.gg/?v=9&encoding=json")
    hello = loads(ws.recv())
    heartbeat_interval = hello['d']['heartbeat_interval']

    payload = {
        "op": 2,
        "d": {
            "token": token,
            "properties": {
                "$os": "windows",
                "$browser": "Discord",
                "$device": "desktop"
            }
        }
    }
    ws.send(dumps(payload))

    payload = {
        "op": 4,
        "d": {
            "guild_id": guild_id,
            "channel_id": channel_id,
            "self_mute": mute,
            "self_deaf": deaf
        }
    }
    ws.send(dumps(payload))

    payload = {
        "op": 18,
        "d": {
            "type": "guild",
            "guild_id": guild_id,
            "channel_id": channel_id,
            "preferred_region": "singapore"
        }
    }
    ws.send(dumps(payload))

    while True:
        message = ws.recv()
        print(f"{Style.BRIGHT} {Fore.CYAN} pajeet ~$ {Fore.YELLOW} Message received. {Fore.RESET}")

        if message.startswith('{"t":"READY"'):
            print(f"{Style.BRIGHT} {Fore.CYAN} pajeet ~$ {Fore.GREEN}Joined voice channel{Fore.RESET}")
            print_menu()
            payload = {
                "op": 4,
                "d": {
                    "guild_id": guild_id,
                    "channel_id": channel_id,
                    "self_mute": mute,
                    "self_deaf": deaf,
                    "self_video": True,
                    "self_stream": True 
                }
            }
            ws.send(dumps(payload))

        sleep(heartbeat_interval / 1000)
        try:
            ws.send(dumps({"op": 1, "d": None}))
        except Exception:
            break

def print_menu():
    print(f"\n{Style.BRIGHT} {Fore.BLACK} DyingV1 ~$ AtheenN {Fore.LIGHTBLACK_EX} {Fore.RESET}")
    print(f"{Style.BRIGHT} {Fore.MAGENTA} DyingV1 ~$ [1] DySpam{Fore.RESET}")
    print(f"{Style.BRIGHT} {Fore.BLUE} DyingV1 ~$ [2] DyBomb{Fore.RESET}")
    print(f"{Style.BRIGHT} {Fore.RED} DyingV1 ~$ [3] Die{Fore.RESET}\n")

def message_spammer_menu():
    tokens = []
    with open(TOKENS_FILE, "r") as file:
        tokens = [line.strip() for line in file.readlines()]

    proxies = []
    with open(PROXIES_FILE, "r") as file:
        proxies = [line.strip() for line in file.readlines()]

    user_ids = []
    with open(USER_IDS_FILE, "r") as file:
        user_ids = [line.strip() for line in file.readlines()]

    if len(tokens) == 0:
        print(f"{Style.BRIGHT} {Fore.RED} pajeet ~$ {Fore.YELLOW} No tokens found in tokens.txt{Fore.RESET}")
        time.sleep(2)
        exit()

    num_processes = min(len(tokens), NUM_PROCESSES)

    processes = []
    for i in range(num_processes):
        process_tokens = tokens[i::num_processes]   
        proxy = proxies[i % len(proxies)] if len(proxies) > 0 else None
        process = multiprocessing.Process(target=send_message, args=(process_tokens, proxy, user_ids))
        process.start()
        processes.append(process)

    try:
        while True:
            x = 1
            x+=1
            
    except KeyboardInterrupt:
        for process in processes:
            process.terminate()
        print(f"{Style.BRIGHT} {Fore.CYAN} pajeet ~$ {Fore.MAGENTA} Message spammer stopped.\n")

def voice_bomber_menu():
    guild_id = input(f"{Style.BRIGHT} {Fore.BLACK} DyingV1 ~$ Guild ID:  {Fore.LIGHTBLACK_EX} {Fore.RESET}")
    channel_id = input(f"{Style.BRIGHT} {Fore.BLACK} DyingV1 ~$ Channel ID:  {Fore.LIGHTBLACK_EX} {Fore.RESET}")
    mute = True
    deaf = True

    tokenlist = open("tokens.txt").read().splitlines()
    executor = ThreadPoolExecutor(max_workers=len(tokenlist))

    for token in tokenlist:
        executor.submit(run_voice, token, guild_id, channel_id, mute, deaf)

def main_menu():
    while True:
        print_menu()
        choice = input(f"{Style.BRIGHT} {Fore.BLACK} DyingV1 ~$ {Fore.LIGHTBLACK_EX} {Fore.RESET}")

        if choice == "1":
            message_spammer_menu()
        elif choice == "2":
            voice_bomber_menu()
        elif choice == "3":
            break
        else:
            print(f"{Style.BRIGHT} {Fore.RED} pajeet ~$ {Fore.YELLOW} Invalid choice. Please try again.\n")

if __name__ == "__main__":
    main_menu()
